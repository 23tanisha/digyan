<!DOCTYPE html>
<html lang="en-GB">

<head>
	<meta charset='UTF-8'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
		<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v23.4 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Kalam Academy</title>
	<meta property="og:locale" content="en_GB" />
	<meta property="og:title" content="Page not found - Kalam Academy" />
	<meta property="og:site_name" content="Kalam Academy" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.kalamacademy.org/#website","url":"https://www.kalamacademy.org/","name":"Kalam Academy","description":"Digital Marketing Institute &amp; Agency In Ranchi","publisher":{"@id":"https://www.kalamacademy.org/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.kalamacademy.org/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-GB"},{"@type":"Organization","@id":"https://www.kalamacademy.org/#organization","name":"Kalam Academy","url":"https://www.kalamacademy.org/","logo":{"@type":"ImageObject","inLanguage":"en-GB","@id":"https://www.kalamacademy.org/#/schema/logo/image/","url":"https://www.kalamacademy.org/wp-content/uploads/2020/10/cropped-KA-1.png","contentUrl":"https://www.kalamacademy.org/wp-content/uploads/2020/10/cropped-KA-1.png","width":376,"height":149,"caption":"Kalam Academy"},"image":{"@id":"https://www.kalamacademy.org/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Kalam Academy &raquo; Feed" href="https://www.kalamacademy.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="Kalam Academy &raquo; Comments Feed" href="https://www.kalamacademy.org/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.kalamacademy.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.5"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='bootstrap-css' href='https://www.kalamacademy.org/wp-content/themes/hestia/assets/bootstrap/css/bootstrap.min.css?ver=1.0.2' type='text/css' media='all' />
<link rel='stylesheet' id='hestia-font-sizes-css' href='https://www.kalamacademy.org/wp-content/themes/hestia/assets/css/font-sizes.min.css?ver=3.1.4' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://www.kalamacademy.org/wp-includes/css/dist/block-library/style.min.css?ver=6.4.5' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--accent: #e91e63;--wp--preset--color--background-color: #ffffff;--wp--preset--color--header-gradient: #a81d84;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='hestia_style-css' href='https://www.kalamacademy.org/wp-content/themes/hestia/style.min.css?ver=3.1.4' type='text/css' media='all' />
<style id='hestia_style-inline-css' type='text/css'>
.elementor-page .hestia-about>.container{width:100%}.elementor-page .pagebuilder-section{padding:0}.elementor-page .title-in-content,.elementor-page .image-in-page{display:none}.home.elementor-page .main-raised>section.hestia-about{overflow:visible}.elementor-editor-active .navbar{pointer-events:none}.elementor-editor-active #elementor.elementor-edit-mode .elementor-element-overlay{z-index:1000000}.elementor-page.page-template-template-fullwidth .blog-post-wrapper>.container{width:100%}.elementor-page.page-template-template-fullwidth .blog-post-wrapper>.container .col-md-12{padding:0}.elementor-page.page-template-template-fullwidth article.section{padding:0}.elementor-text-editor p,.elementor-text-editor h1,.elementor-text-editor h2,.elementor-text-editor h3,.elementor-text-editor h4,.elementor-text-editor h5,.elementor-text-editor h6{font-size:inherit}
.hestia-top-bar,.hestia-top-bar .widget.widget_shopping_cart .cart_list{background-color:#363537}.hestia-top-bar .widget .label-floating input[type=search]:-webkit-autofill{-webkit-box-shadow:inset 0 0 0 9999px #363537}.hestia-top-bar,.hestia-top-bar .widget .label-floating input[type=search],.hestia-top-bar .widget.widget_search form.form-group:before,.hestia-top-bar .widget.widget_product_search form.form-group:before,.hestia-top-bar .widget.widget_shopping_cart:before{color:#fff}.hestia-top-bar .widget .label-floating input[type=search]{-webkit-text-fill-color:#fff !important}.hestia-top-bar div.widget.widget_shopping_cart:before,.hestia-top-bar .widget.widget_product_search form.form-group:before,.hestia-top-bar .widget.widget_search form.form-group:before{background-color:#fff}.hestia-top-bar a,.hestia-top-bar .top-bar-nav li a{color:#fff}.hestia-top-bar ul li a[href*="mailto:"]:before,.hestia-top-bar ul li a[href*="tel:"]:before{background-color:#fff}.hestia-top-bar a:hover,.hestia-top-bar .top-bar-nav li a:hover{color:#eee}.hestia-top-bar ul li:hover a[href*="mailto:"]:before,.hestia-top-bar ul li:hover a[href*="tel:"]:before{background-color:#eee}
a,.navbar .dropdown-menu li:hover>a,.navbar .dropdown-menu li:focus>a,.navbar .dropdown-menu li:active>a,.navbar .navbar-nav>li .dropdown-menu li:hover>a,body:not(.home) .navbar-default .navbar-nav>.active:not(.btn)>a,body:not(.home) .navbar-default .navbar-nav>.active:not(.btn)>a:hover,body:not(.home) .navbar-default .navbar-nav>.active:not(.btn)>a:focus,a:hover,.card-blog a.moretag:hover,.card-blog a.more-link:hover,.widget a:hover,.has-text-color.has-accent-color,p.has-text-color a{color:#e91e63}.svg-text-color{fill:#e91e63}.pagination span.current,.pagination span.current:focus,.pagination span.current:hover{border-color:#e91e63}button,button:hover,.woocommerce .track_order button[type="submit"],.woocommerce .track_order button[type="submit"]:hover,div.wpforms-container .wpforms-form button[type=submit].wpforms-submit,div.wpforms-container .wpforms-form button[type=submit].wpforms-submit:hover,input[type="button"],input[type="button"]:hover,input[type="submit"],input[type="submit"]:hover,input#searchsubmit,.pagination span.current,.pagination span.current:focus,.pagination span.current:hover,.btn.btn-primary,.btn.btn-primary:link,.btn.btn-primary:hover,.btn.btn-primary:focus,.btn.btn-primary:active,.btn.btn-primary.active,.btn.btn-primary.active:focus,.btn.btn-primary.active:hover,.btn.btn-primary:active:hover,.btn.btn-primary:active:focus,.btn.btn-primary:active:hover,.hestia-sidebar-open.btn.btn-rose,.hestia-sidebar-close.btn.btn-rose,.hestia-sidebar-open.btn.btn-rose:hover,.hestia-sidebar-close.btn.btn-rose:hover,.hestia-sidebar-open.btn.btn-rose:focus,.hestia-sidebar-close.btn.btn-rose:focus,.label.label-primary,.hestia-work .portfolio-item:nth-child(6n+1) .label,.nav-cart .nav-cart-content .widget .buttons .button,.has-accent-background-color[class*="has-background"]{background-color:#e91e63}@media(max-width:768px){.navbar-default .navbar-nav>li>a:hover,.navbar-default .navbar-nav>li>a:focus,.navbar .navbar-nav .dropdown .dropdown-menu li a:hover,.navbar .navbar-nav .dropdown .dropdown-menu li a:focus,.navbar button.navbar-toggle:hover,.navbar .navbar-nav li:hover>a i{color:#e91e63}}body:not(.woocommerce-page) button:not([class^="fl-"]):not(.hestia-scroll-to-top):not(.navbar-toggle):not(.close),body:not(.woocommerce-page) .button:not([class^="fl-"]):not(hestia-scroll-to-top):not(.navbar-toggle):not(.add_to_cart_button):not(.product_type_grouped):not(.product_type_external),div.wpforms-container .wpforms-form button[type=submit].wpforms-submit,input[type="submit"],input[type="button"],.btn.btn-primary,.widget_product_search button[type="submit"],.hestia-sidebar-open.btn.btn-rose,.hestia-sidebar-close.btn.btn-rose,.everest-forms button[type=submit].everest-forms-submit-button{-webkit-box-shadow:0 2px 2px 0 rgba(233,30,99,0.14),0 3px 1px -2px rgba(233,30,99,0.2),0 1px 5px 0 rgba(233,30,99,0.12);box-shadow:0 2px 2px 0 rgba(233,30,99,0.14),0 3px 1px -2px rgba(233,30,99,0.2),0 1px 5px 0 rgba(233,30,99,0.12)}.card .header-primary,.card .content-primary,.everest-forms button[type=submit].everest-forms-submit-button{background:#e91e63}body:not(.woocommerce-page) .button:not([class^="fl-"]):not(.hestia-scroll-to-top):not(.navbar-toggle):not(.add_to_cart_button):hover,body:not(.woocommerce-page) button:not([class^="fl-"]):not(.hestia-scroll-to-top):not(.navbar-toggle):not(.close):hover,div.wpforms-container .wpforms-form button[type=submit].wpforms-submit:hover,input[type="submit"]:hover,input[type="button"]:hover,input#searchsubmit:hover,.widget_product_search button[type="submit"]:hover,.pagination span.current,.btn.btn-primary:hover,.btn.btn-primary:focus,.btn.btn-primary:active,.btn.btn-primary.active,.btn.btn-primary:active:focus,.btn.btn-primary:active:hover,.hestia-sidebar-open.btn.btn-rose:hover,.hestia-sidebar-close.btn.btn-rose:hover,.pagination span.current:hover,.everest-forms button[type=submit].everest-forms-submit-button:hover,.everest-forms button[type=submit].everest-forms-submit-button:focus,.everest-forms button[type=submit].everest-forms-submit-button:active{-webkit-box-shadow:0 14px 26px -12px rgba(233,30,99,0.42),0 4px 23px 0 rgba(0,0,0,0.12),0 8px 10px -5px rgba(233,30,99,0.2);box-shadow:0 14px 26px -12px rgba(233,30,99,0.42),0 4px 23px 0 rgba(0,0,0,0.12),0 8px 10px -5px rgba(233,30,99,0.2);color:#fff}.form-group.is-focused .form-control{background-image:-webkit-gradient(linear,left top,left bottom,from(#e91e63),to(#e91e63)),-webkit-gradient(linear,left top,left bottom,from(#d2d2d2),to(#d2d2d2));background-image:-webkit-linear-gradient(linear,left top,left bottom,from(#e91e63),to(#e91e63)),-webkit-linear-gradient(linear,left top,left bottom,from(#d2d2d2),to(#d2d2d2));background-image:linear-gradient(linear,left top,left bottom,from(#e91e63),to(#e91e63)),linear-gradient(linear,left top,left bottom,from(#d2d2d2),to(#d2d2d2))}.navbar:not(.navbar-transparent) li:not(.btn):hover>a,.navbar li.on-section:not(.btn)>a,.navbar.full-screen-menu.navbar-transparent li:not(.btn):hover>a,.navbar.full-screen-menu .navbar-toggle:hover,.navbar:not(.navbar-transparent) .nav-cart:hover,.navbar:not(.navbar-transparent) .hestia-toggle-search:hover{color:#e91e63}.header-filter-gradient{background:linear-gradient(45deg,rgba(168,29,132,1) 0,rgb(234,57,111) 100%)}.has-text-color.has-header-gradient-color{color:#a81d84}.has-header-gradient-background-color[class*="has-background"]{background-color:#a81d84}.has-text-color.has-background-color-color{color:#fff}.has-background-color-background-color[class*="has-background"]{background-color:#fff}
.btn.btn-primary:not(.colored-button):not(.btn-left):not(.btn-right):not(.btn-just-icon):not(.menu-item),input[type="submit"]:not(.search-submit),body:not(.woocommerce-account) .woocommerce .button.woocommerce-Button,.woocommerce .product button.button,.woocommerce .product button.button.alt,.woocommerce .product #respond input#submit,.woocommerce-cart .blog-post .woocommerce .cart-collaterals .cart_totals .checkout-button,.woocommerce-checkout #payment #place_order,.woocommerce-account.woocommerce-page button.button,.woocommerce .track_order button[type="submit"],.nav-cart .nav-cart-content .widget .buttons .button,.woocommerce a.button.wc-backward,body.woocommerce .wccm-catalog-item a.button,body.woocommerce a.wccm-button.button,form.woocommerce-form-coupon button.button,div.wpforms-container .wpforms-form button[type=submit].wpforms-submit,div.woocommerce a.button.alt,div.woocommerce table.my_account_orders .button,.btn.colored-button,.btn.btn-left,.btn.btn-right,.btn:not(.colored-button):not(.btn-left):not(.btn-right):not(.btn-just-icon):not(.menu-item):not(.hestia-sidebar-open):not(.hestia-sidebar-close){padding-top:15px;padding-bottom:15px;padding-left:33px;padding-right:33px}
.btn.btn-primary:not(.colored-button):not(.btn-left):not(.btn-right):not(.btn-just-icon):not(.menu-item),input[type="submit"]:not(.search-submit),body:not(.woocommerce-account) .woocommerce .button.woocommerce-Button,.woocommerce .product button.button,.woocommerce .product button.button.alt,.woocommerce .product #respond input#submit,.woocommerce-cart .blog-post .woocommerce .cart-collaterals .cart_totals .checkout-button,.woocommerce-checkout #payment #place_order,.woocommerce-account.woocommerce-page button.button,.woocommerce .track_order button[type="submit"],.nav-cart .nav-cart-content .widget .buttons .button,.woocommerce a.button.wc-backward,body.woocommerce .wccm-catalog-item a.button,body.woocommerce a.wccm-button.button,form.woocommerce-form-coupon button.button,div.wpforms-container .wpforms-form button[type=submit].wpforms-submit,div.woocommerce a.button.alt,div.woocommerce table.my_account_orders .button,input[type="submit"].search-submit,.hestia-view-cart-wrapper .added_to_cart.wc-forward,.woocommerce-product-search button,.woocommerce-cart .actions .button,#secondary div[id^=woocommerce_price_filter] .button,.woocommerce div[id^=woocommerce_widget_cart].widget .buttons .button,.searchform input[type=submit],.searchform button,.search-form:not(.media-toolbar-primary) input[type=submit],.search-form:not(.media-toolbar-primary) button,.woocommerce-product-search input[type=submit],.btn.colored-button,.btn.btn-left,.btn.btn-right,.btn:not(.colored-button):not(.btn-left):not(.btn-right):not(.btn-just-icon):not(.menu-item):not(.hestia-sidebar-open):not(.hestia-sidebar-close){border-radius:3px}
h1,h2,h3,h4,h5,h6,.hestia-title,.hestia-title.title-in-content,p.meta-in-content,.info-title,.card-title,.page-header.header-small .hestia-title,.page-header.header-small .title,.widget h5,.hestia-title,.title,.footer-brand,.footer-big h4,.footer-big h5,.media .media-heading,.carousel h1.hestia-title,.carousel h2.title,.carousel span.sub-title,.hestia-about h1,.hestia-about h2,.hestia-about h3,.hestia-about h4,.hestia-about h5{font-family:Quicksand}body,ul,.tooltip-inner{font-family:Quicksand}
@media(min-width:769px){.page-header.header-small .hestia-title,.page-header.header-small .title,h1.hestia-title.title-in-content,.main article.section .has-title-font-size{font-size:42px}}
</style>
<link rel='stylesheet' id='hestia-google-font-quicksand-css' href='//fonts.googleapis.com/css?family=Quicksand%3A300%2C400%2C500%2C700&#038;subset=latin&#038;ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css' href='https://www.kalamacademy.org/wp-content/plugins/elementskit-lite/widgets/init/assets/css/widget-styles.css?ver=3.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css' href='https://www.kalamacademy.org/wp-content/plugins/elementskit-lite/widgets/init/assets/css/responsive.css?ver=3.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://www.kalamacademy.org/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.27.7' type='text/css' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://www.kalamacademy.org/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=6.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='wpr-text-animations-css-css' href='https://www.kalamacademy.org/wp-content/plugins/royal-elementor-addons/assets/css/lib/animations/text-animations.min.css?ver=1.7.1027' type='text/css' media='all' />
<link rel='stylesheet' id='wpr-addons-css-css' href='https://www.kalamacademy.org/wp-content/plugins/royal-elementor-addons/assets/css/frontend.min.css?ver=1.7.1027' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://www.kalamacademy.org/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=6.2.0' type='text/css' media='all' />
<script type="text/javascript" data-cfasync="false" src="https://www.kalamacademy.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" data-cfasync="false" src="https://www.kalamacademy.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://www.kalamacademy.org/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.kalamacademy.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.5" />
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-610LQ7D4ST"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-610LQ7D4ST');
</script><meta name="generator" content="Elementor 3.27.7; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<style type="text/css" id="custom-background-css">
body.custom-background { background-color: #ffffff; }
</style>
	<link rel="icon" href="https://www.kalamacademy.org/wp-content/uploads/2024/09/cropped-Untitled-design-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.kalamacademy.org/wp-content/uploads/2024/09/cropped-Untitled-design-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.kalamacademy.org/wp-content/uploads/2024/09/cropped-Untitled-design-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.kalamacademy.org/wp-content/uploads/2024/09/cropped-Untitled-design-270x270.png" />
<style id="wpr_lightbox_styles">
				.lg-backdrop {
					background-color: rgba(0,0,0,0.6) !important;
				}
				.lg-toolbar,
				.lg-dropdown {
					background-color: rgba(0,0,0,0.8) !important;
				}
				.lg-dropdown:after {
					border-bottom-color: rgba(0,0,0,0.8) !important;
				}
				.lg-sub-html {
					background-color: rgba(0,0,0,0.8) !important;
				}
				.lg-thumb-outer,
				.lg-progress-bar {
					background-color: #444444 !important;
				}
				.lg-progress {
					background-color: #a90707 !important;
				}
				.lg-icon {
					color: #efefef !important;
					font-size: 20px !important;
				}
				.lg-icon.lg-toogle-thumb {
					font-size: 24px !important;
				}
				.lg-icon:hover,
				.lg-dropdown-text:hover {
					color: #ffffff !important;
				}
				.lg-sub-html,
				.lg-dropdown-text {
					color: #efefef !important;
					font-size: 14px !important;
				}
				#lg-counter {
					color: #efefef !important;
					font-size: 14px !important;
				}
				.lg-prev,
				.lg-next {
					font-size: 35px !important;
				}

				/* Defaults */
				.lg-icon {
				background-color: transparent !important;
				}

				#lg-counter {
				opacity: 0.9;
				}

				.lg-thumb-outer {
				padding: 0 10px;
				}

				.lg-thumb-item {
				border-radius: 0 !important;
				border: none !important;
				opacity: 0.5;
				}

				.lg-thumb-item.active {
					opacity: 1;
				}
	         </style>	
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-610LQ7D4ST"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-610LQ7D4ST');
  </script>
  <script type="text/javascript">
    (function (c, l, a, r, i, t, y) {
      c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments) };
      t = l.createElement(r); t.async = 1; t.src = "https://www.clarity.ms/tag/" + i;
      y = l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t, y);
    })(window, document, "clarity", "script", "hrckolcaii");
  </script>
	
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-624423675"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-624423675');
</script>

	<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '999133924935385');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=999133924935385&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
	
	
</head>

<body data-rsssl=1 class="error404 custom-background wp-custom-logo header-layout-default elementor-default elementor-kit-1314">
		<div class="wrapper  default ">
		<header class="header ">
			<div style="display: none"></div>		<nav class="navbar navbar-default navbar-fixed-top  no-slider hestia_left navbar-not-transparent">
						<div class="container">
						<div class="navbar-header">
			<div class="title-logo-wrapper">
				<a class="navbar-brand" href="https://www.kalamacademy.org/"
						title="Kalam Academy">
					<img loading="lazy"  src="https://www.kalamacademy.org/wp-content/uploads/2020/10/cropped-KA-1.png" alt="Kalam Academy" width="376" height="149"></a>
			</div>
								<div class="navbar-toggle-wrapper">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navigation">
								<span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>				<span class="sr-only">Toggle Navigation</span>
			</button>
					</div>
				</div>
		<div id="main-navigation" class="collapse navbar-collapse"><ul id="menu-new-main-menu" class="nav navbar-nav"><li id="menu-item-693" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-693"><a title="Home" href="https://kalamacademy.org/">Home</a></li>
<li id="menu-item-4518" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4518 dropdown"><a title="Course" href="#" class="dropdown-toggle">Course <span class="caret-wrap"><span class="caret"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-down" class="svg-inline--fa fa-chevron-down fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path></svg></span></span></a>
<ul role="menu" class="dropdown-menu">
	<li id="menu-item-953" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-953"><a title="Digital Marketing Course" href="https://www.kalamacademy.org/digital-marketing-course-in-ranchi/">Digital Marketing Course</a></li>
	<li id="menu-item-4520" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4520"><a title="Complete Web Development Course" href="https://www.kalamacademy.org/php-training-web-design-development-course-in-ranchi/">Complete Web Development Course</a></li>
</ul>
</li>
<li id="menu-item-954" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-954 dropdown"><a title="Services" href="https://www.kalamacademy.org/business/" class="dropdown-toggle">Services <span class="caret-wrap"><span class="caret"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-down" class="svg-inline--fa fa-chevron-down fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path></svg></span></span></a>
<ul role="menu" class="dropdown-menu">
	<li id="menu-item-955" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-955"><a title="WEB DEVELOPMENT" href="https://www.kalamacademy.org/digital-services-in-ranchi/">WEB DEVELOPMENT</a></li>
	<li id="menu-item-956" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-956"><a title="ONLINE ADVERTISEMENT" href="https://www.kalamacademy.org/digital-services-in-ranchi/">ONLINE ADVERTISEMENT</a></li>
	<li id="menu-item-957" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-957"><a title="GRAPHIC DESIGNING" href="https://www.kalamacademy.org/digital-services-in-ranchi/">GRAPHIC DESIGNING</a></li>
	<li id="menu-item-958" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-958"><a title="WEBSITE SEO" href="https://www.kalamacademy.org/digital-services-in-ranchi/">WEBSITE SEO</a></li>
	<li id="menu-item-960" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-960"><a title="MOBILE APP DEVELOPMENT" href="https://www.kalamacademy.org/digital-services-in-ranchi/">MOBILE APP DEVELOPMENT</a></li>
</ul>
</li>
<li id="menu-item-2663" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2663 dropdown"><a title="Product" href="#" class="dropdown-toggle">Product <span class="caret-wrap"><span class="caret"><svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-down" class="svg-inline--fa fa-chevron-down fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z"></path></svg></span></span></a>
<ul role="menu" class="dropdown-menu">
	<li id="menu-item-1399" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1399"><a title="Grocery App" href="https://www.kalamacademy.org/online-grocery-business/">Grocery App</a></li>
	<li id="menu-item-2666" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2666"><a title="Service App" href="https://www.kalamacademy.org/start-online-doorstep-service-business/">Service App</a></li>
	<li id="menu-item-4428" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4428"><a title="Website" href="https://www.kalamacademy.org/website-development-company-in-india-web-designing-company-in-india/">Website</a></li>
</ul>
</li>
<li id="menu-item-8191" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8191"><a title="We are hiring" href="https://www.kalamacademy.org/job-in-ranchi-office-job-in-ranchi/"><b> <font color="f87903">We are hiring</font></b></a></li>
</ul></div>			</div>
					</nav>
				</header>
<div id="primary" class="boxed-layout-header page-header header-small" data-parallax="active" ><div class="container"><div class="row"><div class="col-md-10 col-md-offset-1 text-center"><h1 class="hestia-title">Oops! That page can&rsquo;t be found.</h1></div></div></div><div class="header-filter header-filter-gradient"></div></div><div class="main  main-raised "><div class="hestia-blogs" data-layout="sidebar-right"><div class="container"><div class="row"><div class="col-md-8 blog-posts-wrap"><article id="post-0" class="section section-text"><div class="row"><div class="col-md-8 col-md-offset-2"><p>It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.</p><form role="search" method="get" class="search-form" action="https://www.kalamacademy.org/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></div></div></article></div>	<div class="col-md-3 blog-sidebar-wrapper col-md-offset-1">
		<aside id="secondary" class="blog-sidebar" role="complementary">
						<div id="text-2" class="widget widget_text"><h5>Best Digital Marketing Course In Ranchi</h5>			<div class="textwidget"><div id="attachment_1123" style="width: 510px" class="wp-caption aligncenter"><a href="https://www.kalamacademy.org/digital-marketing-course-in-ranchi/"><img fetchpriority="high" fetchpriority="high" decoding="async" aria-describedby="caption-attachment-1123" class="wp-image-1123 size-medium" src="https://www.kalamacademy.org/wp-content/uploads/2019/12/Want-To-Learn-Digital-Marketing-In-Ranchi_-2-500x317.jpg" alt="Digital Marketing Course In Ranchi" width="500" height="317" /></a><p id="caption-attachment-1123" class="wp-caption-text"><a href="https://www.kalamacademy.org/digital-marketing-course-in-ranchi/">Digital Marketing Course In Ranchi</a></p></div>
</div>
		</div><div id="text-5" class="widget widget_text"><h5>Get Digital Marketing Services In Ranchi</h5>			<div class="textwidget"><div id="attachment_1121" style="width: 510px" class="wp-caption alignnone"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/"><img decoding="async" aria-describedby="caption-attachment-1121" class="size-medium wp-image-1121" src="https://www.kalamacademy.org/wp-content/uploads/2019/12/Want-To-Learn-Digital-Marketing-In-Ranchi_-1-500x317.jpg" alt="" width="500" height="317" /></a><p id="caption-attachment-1121" class="wp-caption-text"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">Get Kalam Academy Digital Services</a></p></div>
</div>
		</div>
		<div id="recent-posts-3" class="widget widget_recent_entries">
		<h5>Recent Posts</h5>
		<ul>
											<li>
					<a href="https://www.kalamacademy.org/bpo-call-center-telecaller-jobs-in-ranchi/">BPO Call Center &#038; Telecaller Jobs in Ranchi</a>
									</li>
											<li>
					<a href="https://www.kalamacademy.org/web-development-courses-in-ranchi/">Top Web Development Institute in Ranchi Comparison [Course +Duration +Fee]</a>
									</li>
											<li>
					<a href="https://www.kalamacademy.org/digital-marketing-courses-in-ranchi/">Digital Marketing Courses in Ranchi with Guaranteed Placement (2024)</a>
									</li>
											<li>
					<a href="https://www.kalamacademy.org/jobs-in-ranchi/">📌2346 Verified “Jobs in Ranchi 2025 | Salary ₹8K &#8211; ₹95K | for Students &amp; Freshers&#8221;</a>
									</li>
											<li>
					<a href="https://www.kalamacademy.org/my-shop/">My Shop</a>
									</li>
					</ul>

		</div><div id="categories-3" class="widget widget_categories"><h5>Categories</h5>
			<ul>
					<li class="cat-item cat-item-92"><a href="https://www.kalamacademy.org/category/pos/category/add-category/">Add Category</a>
</li>
	<li class="cat-item cat-item-93"><a href="https://www.kalamacademy.org/category/pos/category/add-library-category/">Add Library Category</a>
</li>
	<li class="cat-item cat-item-89"><a href="https://www.kalamacademy.org/category/pos/product/add-new-product/">Add New Product</a>
</li>
	<li class="cat-item cat-item-96"><a href="https://www.kalamacademy.org/category/addons/">Addons</a>
</li>
	<li class="cat-item cat-item-91"><a href="https://www.kalamacademy.org/category/pos/category/">Category</a>
</li>
	<li class="cat-item cat-item-100"><a href="https://www.kalamacademy.org/category/addons/delivery-slot/">Delivery Slot</a>
</li>
	<li class="cat-item cat-item-69"><a href="https://www.kalamacademy.org/category/digital-marketing-course/">Digital Marketing Course</a>
</li>
	<li class="cat-item cat-item-111"><a href="https://www.kalamacademy.org/category/job-in-ranchi/">Job In Ranchi</a>
</li>
	<li class="cat-item cat-item-87"><a href="https://www.kalamacademy.org/category/pos/">POS</a>
</li>
	<li class="cat-item cat-item-88"><a href="https://www.kalamacademy.org/category/pos/product/">Product</a>
</li>
	<li class="cat-item cat-item-66"><a href="https://www.kalamacademy.org/category/products/">Products</a>
</li>
	<li class="cat-item cat-item-25"><a href="https://www.kalamacademy.org/category/student-tips/">Student Tips</a>
</li>
	<li class="cat-item cat-item-97"><a href="https://www.kalamacademy.org/category/addons/theme/">Theme</a>
</li>
	<li class="cat-item cat-item-1"><a href="https://www.kalamacademy.org/category/uncategorised/">Uncategorized</a>
</li>
	<li class="cat-item cat-item-94"><a href="https://www.kalamacademy.org/category/user/">User</a>
</li>
	<li class="cat-item cat-item-112"><a href="https://www.kalamacademy.org/category/web-development-course/">Web Development Course</a>
</li>
	<li class="cat-item cat-item-86"><a href="https://www.kalamacademy.org/category/%e0%a4%a1%e0%a4%bf%e0%a4%9c%e0%a4%bf%e0%a4%9f%e0%a4%b2-%e0%a4%ae%e0%a4%be%e0%a4%b0%e0%a5%8d%e0%a4%95%e0%a5%87%e0%a4%9f%e0%a4%bf%e0%a4%82%e0%a4%97-%e0%a4%b9%e0%a4%bf%e0%a4%82%e0%a4%a6%e0%a5%80/">डिजिटल मार्केटिंग हिंदी में-Digital Marketing in Hindi</a>
</li>
			</ul>

			</div><div id="nav_menu-3" class="widget widget_nav_menu"><h5>Go TO</h5><div class="menu-new-main-menu-container"><ul id="menu-new-main-menu-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-693"><a href="https://kalamacademy.org/">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-4518"><a href="#">Course</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-953"><a href="https://www.kalamacademy.org/digital-marketing-course-in-ranchi/">Digital Marketing Course</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4520"><a href="https://www.kalamacademy.org/php-training-web-design-development-course-in-ranchi/">Complete Web Development Course</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-954"><a href="https://www.kalamacademy.org/business/">Services</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-955"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">WEB DEVELOPMENT</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-956"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">ONLINE ADVERTISEMENT</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-957"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">GRAPHIC DESIGNING</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-958"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">WEBSITE SEO</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-960"><a href="https://www.kalamacademy.org/digital-services-in-ranchi/">MOBILE APP DEVELOPMENT</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2663"><a href="#">Product</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1399"><a href="https://www.kalamacademy.org/online-grocery-business/">Grocery App</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2666"><a href="https://www.kalamacademy.org/start-online-doorstep-service-business/">Service App</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4428"><a href="https://www.kalamacademy.org/website-development-company-in-india-web-designing-company-in-india/">Website</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8191"><a href="https://www.kalamacademy.org/job-in-ranchi-office-job-in-ranchi/"><b> <font color="f87903">We are hiring</font></b></a></li>
</ul></div></div>					</aside><!-- .sidebar .widget-area -->
	</div>
	</div></div></div>			</div>
			<script>
				;
				(function($, w) {
					'use strict';
					let $window = $(w);

					$(document).ready(function() {

						let isEnable = "";
						let isEnableLazyMove = "";
						let speed = isEnableLazyMove ? '0.7' : '0.2';

						if( !isEnable ) {
							return;
						}

						if (typeof haCursor == 'undefined' || haCursor == null) {
							initiateHaCursorObject(speed);
						}

						setTimeout(function() {
							let targetCursor = $('.ha-cursor');
							if (targetCursor) {
								if (!isEnable) {
									$('body').removeClass('hm-init-default-cursor-none');
									$('.ha-cursor').addClass('ha-init-hide');
								} else {
									$('body').addClass('hm-init-default-cursor-none');
									$('.ha-cursor').removeClass('ha-init-hide');
								}
							}
						}, 500);

					});

				}(jQuery, window));
			</script>
		
					<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/royal-elementor-addons/assets/js/lib/particles/particles.js?ver=3.0.6" id="wpr-particles-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/royal-elementor-addons/assets/js/lib/jarallax/jarallax.min.js?ver=1.12.7" id="wpr-jarallax-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/royal-elementor-addons/assets/js/lib/parallax/parallax.min.js?ver=1.0" id="wpr-parallax-hover-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/themes/hestia/assets/bootstrap/js/bootstrap.min.js?ver=1.0.2" id="jquery-bootstrap-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="hestia_scripts-js-extra">
/* <![CDATA[ */
var requestpost = {"ajaxurl":"https:\/\/www.kalamacademy.org\/wp-admin\/admin-ajax.php","disable_autoslide":"","masonry":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/themes/hestia/assets/js/script.min.js?ver=3.1.4" id="hestia_scripts-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=3.5.5" id="elementskit-framework-js-frontend-js"></script>
<script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
/* <![CDATA[ */
		var elementskit = {
			resturl: 'https://www.kalamacademy.org/wp-json/elementskit/v1/',
		}

		
/* ]]> */
</script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=3.5.5" id="ekit-widget-scripts-js"></script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/happy-elementor-addons/assets/js/extension-reading-progress-bar.min.js?ver=3.18.1" id="happy-reading-progress-bar-js"></script>
<script type="text/javascript" id="eael-general-js-extra">
/* <![CDATA[ */
var localize = {"ajaxurl":"https:\/\/www.kalamacademy.org\/wp-admin\/admin-ajax.php","nonce":"f450a1611a","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"","cart_redirectition":"no","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.kalamacademy.org/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=6.2.0" id="eael-general-js"></script>
</body>
</html>
